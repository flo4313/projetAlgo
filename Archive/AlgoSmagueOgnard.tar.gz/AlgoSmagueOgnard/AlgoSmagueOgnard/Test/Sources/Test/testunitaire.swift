import Type

//
//  testunitaires.swift
//

import Foundation

func testestvideCDB() {
    var cdb : ChampDeBataille
    cdb.init()
    var nb : Int
    nb = nombreCarteCollection(cdb)
    try (nb == 0)
}

func testAjoutCarteCDB () {
    let position : Position
    position.init()
    guard position == Vide else { return }
    let cdb : ChampDeBataille
    cdb.init()
    let carte : Carte
    carte.init()
    do {
        try getCarteCDB(position) == carte
    }
    catch {
        print("on ne peut pas ajouter de carte si la position n'est pas vide : il y a déjà une carte ! ")
    }
}

func testSupprimerCarteCDB () {
    var cdb : ChampDeBataille
    cdb.init()
    var position : Position
    position.init()
    var carte : Carte
    carte.init()
    try ( getCarteCDB(position) == Vide )
}

func testnbCarteCDB () {
    var cdb : ChampDeBataille
    cdb.init()
    var compteur = 0
    do {
        for pos in cdb {
            if pos != Vide {
                compteur += 1
            }
        }
        try nombreCarte_CDB(cdb) == compteur
    }
    
    
    func testestvideCollection () {
        var cdb : ChampDeBataille
        cdb.init()
        do {
            let nb = nombreCarteCollection(cdb)
            try nb == 0
        }
    }
    
    func testAjoutCarteCollection () {
        guard !(Pioche.CollectiondeCarte) else {  return }
        var carte : Carte
        carte.init()
        let nom : TypedeCarte
        nom = getNomCarte(carte)
        var col : CollectiondeCarte
        var r1 = 0
        var r2 = 0
        var s1 = 0
        var s2 = 0
        var a1 = 0
        var a2 = 0
        var g1 = 0
        var g2 = 0
        do {
            for i in col {
                if Carte.getNom(i) == Roi1 || Carte.getNom(i) == Roi2 {r1+=1}
                else if Carte.getNom(i) == Soldat  {s1+=1}
                else if Carte.getNom(i) == Archer {a1+=1}
                else if Carte.getNom(i) == Garde{ g1+=1 }
            }
            if nom == Roi1 || nom == Roi2 { r1+=1}
            if nom == Soldat { s1+=1}
            if nom == Archer { a1+=1}
            if nom == Garde { g1+=1}
            
            for j in col.ajouterCarteCollection(carte) {
                if Carte.getNom(j) == Roi1 || Carte.getNom(j) == Roi2 {r2+=1}
                else if Carte.getNom(j) == Soldat {s2+=1}
                else if Carte.getNom(j) == Archer {a2+=1}
                else {
                    g2+=1
                }
            }
            try (a1+s1+g1+r1)==(a2+r2+g2+s2)
        }
        catch { print("On ne peut pas ajouter de carte dans la pioche pendant la partie")}
    }
    
    func testSupprimerCarteCollection () {
        guard !(Cimetiere.Collection) else { return}
        var carte : Carte
        carte.init()
        let nom : TypedeCarte
        nom = getNomCarte(carte)
        var col : CollectiondeCarte
        var r1 = 0
        var r2 = 0
        var s1 = 0
        var s2 = 0
        var a1 = 0
        var a2 = 0
        var g1 = 0
        var g2 = 0
        do {
            for i in col {
                if Carte.getNom(i) == Roi  {r1+=1}
                else if Carte.getNom(i) == Soldat  {s1+=1}
                else if Carte.getNom(i) == Archer  {a1+=1}
                else if Carte.getNom(i) == Garde {
                    g1+=1
                }
            }
            if nom == Roi1 || nom == Roi2 { r1-=1}
            if nom == Soldat { s1-=1}
            if nom == Archer { a1-=1}
            if nom == Garde { g1-=1}
            for j in col.ajouterCarteCollection(carte) {
                if Carte.getNom(j) == Roi{r2+=1}
                else if Carte.getNom(j) == Soldat {s2+=1}
                else if Carte.getNom(j) == Archer {a2+=1}
                else {
                    g2+=1
                }
            }
            try (a1+s1+g1+r1)==(a2+r2+g2+s2)
        }
        catch { print("on ne peut pas enlever de carte dans le cimetière")}
    }
    
    func testnombreCarteCollection () {
        var col : CollectiondeCarte
        col.init()
        var nb = 0
        do {
            for i in col {
                nb+=1
            }
            try nb == nombreCarteCollection(col)
        }
    }
    
    
    
    func testgetestpositionDef () {
        var carte : Carte
        carte.init()
        do {
            try mettrepositionDef(carte) == getestpositionDef(carte)
        }
    }
    
    
    
    
    func testmettrepositionOff () {
        var carte : Carte
        carte.init()
        do {
            carte.mettrepositionDef()
            if !getestpositionDef(carte) {
                return True
            }
            else { return False}
        }
        
    }
    
    
    func testmettrepositionDef () {
        var carte : Carte
        carte.init()
        
        do {
            carte.mettrepositionDef()
            if getestpositionDef(carte) {
                return True
            }
            else { return False}
        }
        
    }
    
    
    func testsubirDegats () {
        let deg : Int
        guard deg => 0 else {return}
        let carte : Carte
        carte.init()
        var carte2 : Carte
        carte2 = carte
        do {
            try ((carte2.getValDef() - deg) == subirdegat(carte).getValDef())
        }
        catch {
            print("la valeur de dégats doit être positive!")
        }
    }
    
    
    
    func testreinitCarte () {
        var carte : Carte
        let c : Carte
        c.init()
        carte.init()
        TypedeCarte.c = TypedeCarte.carte
        
        try reinit(carte)==c
    }
    
    func testChangeValAtq() {
        let carte : Carte
        carte.init()
        let val : Int
        val = 1
        guard carte.TypedeCarte = Soldat && val > 0 else {return}
        do {
            try getValAtq(carte.changeValAtq(val))==val
        }
        catch {
            print("vous n'avez pas mis un soldat ou l'entier choisi n'est pas positif")
        }
    }
    
    
    
    
    func testgetMain () {
        let joueur : Joueur
        joueur.init(j1)
        let main : CollectiondeCarte
        main = Main.TypedeCollection
        main.init()
        try main == getMain(j1)
    }
    
    func testgetCimetiere() {
        let joueur : Joueur
        joueur.init(j1)
        let cimetiere : CollectiondeCarte
        cimetiere.init()
        cimetiere = Cimetiere.TypedeCollection
        try cimetiere == getCimetiere(j1)
    }
    
    func testgetRoyaume () {
        let joueur : Joueur
        joueur.init(j1)
        let royaume : CollectiondeCarte
        royaume = Royaume.TypedeCollection
        royaume.init()
        try royaume == getRoyaume(j1)
}


    func testgetPioche () {
        let joueur : Joueur
        joueur.init(j1)
        let pioche : CollectiondeCarte
        pioche = Pioche.TypedeCollection
        pioche.init()
        try pioche == getPioche(j1)
}

