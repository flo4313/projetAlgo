import XCTest

import TestTests

var tests = [XCTestCaseEntry]()
tests += TestTests.allTests()
XCTMain(tests)
