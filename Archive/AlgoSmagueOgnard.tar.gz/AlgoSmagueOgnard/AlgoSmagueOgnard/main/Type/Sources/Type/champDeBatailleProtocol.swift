//  Created by Alexia Ognard on 30/11/2018.
//
// type Champ de Bataille et ses propriétés

import Foundation



// Champ de Bataille est une collection
// Cette collection peut être parcouru par un itérateur
protocol ChampDeBatailleProtocol : Sequence{
    associatedtype ItCDB : IteratorProtocol where ItCDB.Element == Position

    //créer un champ de Bataille composé de 6 positions vides A1,A2,A3,F1,F2,F3
    init()
    
    //renvoie un booléen si le CDB est vide ou non
    //estvideCDB: ChampDeBatailleProtocol -> Bool
    //pré : on prend en paramètre un champ de bataille
    //post: renvoie True si le CDB est vide, False sinon
    func estvideCDB() -> Bool
    
    //ajouter une carte dans le CDB
    // ajouterCarteCDB: ChampDeBatailleProtocol x Carte x Position -> ChampDeBatailleProtocol
    //pré : prend en paramètre une carte, sa position. La position doit être vide pour pouvoir ajouter une carte dans celle-ci
    //post : renvoie le champ de bataille avec la nouvelle carte
    // si la position demandée est déjà prise par une carte alors on remplace celle-ci et on place l'autre carte dans la main
    mutating func ajouterCarteCDB (carte : Carte, position : Position) -> Self
    
    //enlève une carte du CDB
    //enleverCarteCDB: ChampDeBatailleProtocol x Position -> ChampDeBatailleProtocol
    //pré: on prend en paramètre une position
    //post: renvoie le champ de bataille sans la carte
    mutating func enleverCarteCDB(position: Position)-> Self
    
    //renvoie le nombre de carte dans le CDB
    //nombreCarteCDB : ChampDeBatailleProtocol -> Int
    //pré: prend en paramètre un champ de bataille
    //post : renvoie le nombre de cartes présentes dans le champ de bataille
    func nombreCarteCDB (cdb : ChampDeBatailleProtocol) -> Int
    
    //renvoie la carte qui est à une positiondans le CDB
    //getCarteCDB : ChampDeBatailleProtocol x Position -> (Carte | Vide)
    //pré: on prend en argument une poisition et le champ de bataille
    //post : on renvoie le type de carte s'il y en a une : soit Roi, soit Archer, soit Garde, soit Soldat; ou vide s'il n'y a pas de carte
    func getCarteCDB(position: Position)->Carte?

    // crée un itérateur sur le champ de bataille pour itérer avec for in. L’itération se fait sur les différentes positions possibles sur le champ de bataille (A1,A2,A3,F1,F2,F3)
    // makeIterator : ChampDeBatailleProtocol -> ItCDB
    func makeIterator()->ItCDB


    // Retourne les positions du champ de bataille
    func getPositions()->ChampDeBataille

    // Reinitialise tout les degats des cartes
    func reinitCartes()->ChampDeBataille

    //Defini si des cartes sont en position defensives pour pouvoir attaquer
    func estPosDef()->Bool

    // mettre une carte en position offensive
    func mettrePositionOffensive(pos: Position)->ChampDeBataille


}
